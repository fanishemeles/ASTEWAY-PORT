import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';

export interface DbOffice {
  id: string;
  slug: string;
  name: string;
  name_am: string;
  category: string;
  description: string;
  description_am: string;
  icon: string;
  address: string | null;
  phone: string | null;
  working_hours: string | null;
  updated_at: string;
  services: DbService[];
  announcements: DbAnnouncement[];
}

export interface DbService {
  id: string;
  office_id: string;
  name: string;
  name_am: string;
  description: string;
  description_am: string;
  fee: string | null;
  processing_time: string | null;
  updated_at: string;
  service_documents: DbDocument[];
}

export interface DbDocument {
  id: string;
  name: string;
  name_am: string;
  sort_order: number;
}

export interface DbAnnouncement {
  id: string;
  office_id: string;
  title: string;
  title_am: string;
  content: string;
  content_am: string;
  type: string;
  published_at: string;
}

export function useOffices() {
  return useQuery({
    queryKey: ['offices'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('offices')
        .select(`
          *,
          services (
            *,
            service_documents (*)
          ),
          announcements (*)
        `)
        .order('name');

      if (error) throw error;

      // Sort service_documents by sort_order
      return (data as unknown as DbOffice[]).map((office) => ({
        ...office,
        services: office.services.map((s) => ({
          ...s,
          service_documents: [...s.service_documents].sort((a, b) => a.sort_order - b.sort_order),
        })),
      }));
    },
  });
}

export function useOfficeBySlug(slug: string | undefined) {
  return useQuery({
    queryKey: ['office', slug],
    queryFn: async () => {
      if (!slug) return null;
      const { data, error } = await supabase
        .from('offices')
        .select(`
          *,
          services (
            *,
            service_documents (*)
          ),
          announcements (*)
        `)
        .eq('slug', slug)
        .single();

      if (error) throw error;

      const office = data as unknown as DbOffice;
      return {
        ...office,
        services: office.services.map((s) => ({
          ...s,
          service_documents: [...s.service_documents].sort((a, b) => a.sort_order - b.sort_order),
        })),
      };
    },
    enabled: !!slug,
  });
}
