import { useParams, Link } from 'react-router-dom';
import { useOfficeBySlug } from '@/hooks/useOffices';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ChatWidget from '@/components/ChatWidget';
import {
  ChevronLeft, MapPin, Phone, Clock, FileText, CheckCircle2,
  AlertTriangle, Info, Calendar, Loader2,
} from 'lucide-react';

const announcementIcon = { info: Info, warning: AlertTriangle, urgent: AlertTriangle };
const announcementStyles = {
  info: 'border-primary/20 bg-eth-green-light',
  warning: 'border-secondary/30 bg-gold-light',
  urgent: 'border-destructive/30 bg-destructive/5',
};

const OfficeDetail = () => {
  const { slug } = useParams();
  const { data: office, isLoading } = useOfficeBySlug(slug);

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!office) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <p className="text-lg font-semibold text-foreground">መስሪያ ቤቱ አልተገኘም</p>
            <p className="text-muted-foreground mt-1">Office not found</p>
            <Link to="/" className="mt-4 inline-block text-sm text-primary hover:underline">
              ← ወደ መነሻ ይመለሱ / Back to home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="eth-gradient">
          <div className="container py-8">
            <Link to="/" className="inline-flex items-center gap-1 text-sm text-primary-foreground/70 hover:text-primary-foreground mb-4">
              <ChevronLeft className="h-4 w-4" />
              ወደ ሁሉም መስሪያ ቤቶች / All Offices
            </Link>
            <h1 className="font-display text-2xl font-bold text-primary-foreground md:text-3xl">
              {office.name_am}
            </h1>
            <p className="text-primary-foreground/70 mt-1">{office.name}</p>
            <div className="mt-4 flex flex-wrap gap-4 text-sm text-primary-foreground/80">
              {office.address && (
                <span className="inline-flex items-center gap-1.5"><MapPin className="h-4 w-4" /> {office.address}</span>
              )}
              {office.phone && (
                <span className="inline-flex items-center gap-1.5"><Phone className="h-4 w-4" /> {office.phone}</span>
              )}
              {office.working_hours && (
                <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" /> {office.working_hours}</span>
              )}
            </div>
          </div>
        </div>

        <div className="container py-8">
          {office.announcements.length > 0 && (
            <div className="mb-8 space-y-3">
              <h2 className="font-display text-lg font-semibold text-foreground">📢 ማስታወቂያዎች / Announcements</h2>
              {office.announcements.map((ann) => {
                const AnnIcon = announcementIcon[ann.type as keyof typeof announcementIcon] || Info;
                const style = announcementStyles[ann.type as keyof typeof announcementStyles] || announcementStyles.info;
                return (
                  <div key={ann.id} className={`rounded-xl border p-4 ${style}`}>
                    <div className="flex items-start gap-3">
                      <AnnIcon className="h-5 w-5 mt-0.5 shrink-0 text-foreground/70" />
                      <div>
                        <p className="font-semibold text-foreground">{ann.title_am}</p>
                        <p className="text-sm text-muted-foreground">{ann.title}</p>
                        <p className="mt-2 text-sm text-foreground/80">{ann.content_am}</p>
                        <p className="text-sm text-muted-foreground">{ann.content}</p>
                        <p className="mt-2 text-xs text-muted-foreground inline-flex items-center gap-1">
                          <Calendar className="h-3 w-3" /> {new Date(ann.published_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <h2 className="font-display text-lg font-semibold text-foreground mb-4">📋 አገልግሎቶች / Services</h2>
          <div className="space-y-4">
            {office.services.map((service) => (
              <div key={service.id} className="glass-card rounded-xl p-5 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-display font-semibold text-foreground flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      {service.name_am}
                    </h3>
                    <p className="text-sm text-muted-foreground">{service.name}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{service.description_am}</p>
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground inline-flex items-center gap-1 bg-muted rounded-md px-2 py-1">
                    <Calendar className="h-3 w-3" />
                    {new Date(service.updated_at).toLocaleDateString()}
                  </span>
                </div>

                <div className="mt-4">
                  <p className="text-sm font-semibold text-foreground mb-2">የሚያስፈልጉ ሰነዶች / Required Documents:</p>
                  <ul className="space-y-1.5">
                    {service.service_documents.map((doc) => (
                      <li key={doc.id} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                        <span>
                          <span className="text-foreground">{doc.name_am}</span>
                          <span className="text-muted-foreground"> — {doc.name}</span>
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4 flex flex-wrap gap-4">
                  {service.fee && (
                    <div className="rounded-lg bg-gold-light px-3 py-2">
                      <p className="text-xs text-muted-foreground">ክፍያ / Fee</p>
                      <p className="text-sm font-semibold text-foreground">{service.fee}</p>
                    </div>
                  )}
                  {service.processing_time && (
                    <div className="rounded-lg bg-eth-green-light px-3 py-2">
                      <p className="text-xs text-muted-foreground">ጊዜ / Processing Time</p>
                      <p className="text-sm font-semibold text-foreground">{service.processing_time}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
      <ChatWidget />
    </div>
  );
};

export default OfficeDetail;
