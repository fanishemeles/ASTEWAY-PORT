import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth, useOfficerProfile } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import {
  Loader2, LogOut, Plus, Trash2, Save, Megaphone, FileText, Building,
} from 'lucide-react';

const AdminDashboard = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const { data: profile, isLoading: profileLoading } = useOfficerProfile(user?.id);
  const queryClient = useQueryClient();

  if (authLoading || profileLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/officer-login" replace />;

  const office = (profile as any)?.offices;
  const officeId = profile?.office_id;

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-2xl font-bold text-foreground">
              {office ? `${office.name_am}` : 'የኦፊሰር ዳሽቦርድ'}
            </h1>
            <p className="text-sm text-muted-foreground">
              {profile?.full_name || user.phone} · Officer Dashboard
            </p>
          </div>
          <button
            onClick={signOut}
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <LogOut className="h-4 w-4" /> ውጣ / Logout
          </button>
        </div>

        {!officeId ? (
          <div className="glass-card rounded-xl p-8 text-center">
            <Building className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="font-display text-lg font-semibold text-foreground">ምንም መስሪያ ቤት አልተመደበም</h2>
            <p className="text-sm text-muted-foreground mt-1">
              No office has been assigned to your account yet. Please contact an administrator.
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            <ServiceManager officeId={officeId} />
            <AnnouncementManager officeId={officeId} />
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

function ServiceManager({ officeId }: { officeId: string }) {
  const queryClient = useQueryClient();
  const [newService, setNewService] = useState({ name: '', name_am: '', description: '', description_am: '', fee: '', processing_time: '' });
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleAddService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newService.name || !newService.name_am) return;
    setSaving(true);
    await supabase.from('services').insert({
      office_id: officeId,
      name: newService.name,
      name_am: newService.name_am,
      description: newService.description,
      description_am: newService.description_am,
      fee: newService.fee || null,
      processing_time: newService.processing_time || null,
    });
    setNewService({ name: '', name_am: '', description: '', description_am: '', fee: '', processing_time: '' });
    setAdding(false);
    setSaving(false);
    queryClient.invalidateQueries({ queryKey: ['offices'] });
    queryClient.invalidateQueries({ queryKey: ['office'] });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          አገልግሎቶች / Services
        </h2>
        <button
          onClick={() => setAdding(!adding)}
          className="inline-flex items-center gap-1.5 rounded-lg eth-gradient px-3 py-2 text-sm font-medium text-primary-foreground"
        >
          <Plus className="h-4 w-4" /> አዲስ / Add
        </button>
      </div>

      {adding && (
        <form onSubmit={handleAddService} className="glass-card rounded-xl p-5 mb-4 space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <input value={newService.name_am} onChange={(e) => setNewService({ ...newService, name_am: e.target.value })}
              placeholder="ስም (አማርኛ)" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <input value={newService.name} onChange={(e) => setNewService({ ...newService, name: e.target.value })}
              placeholder="Name (English)" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <input value={newService.description_am} onChange={(e) => setNewService({ ...newService, description_am: e.target.value })}
              placeholder="መግለጫ (አማርኛ)" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <input value={newService.description} onChange={(e) => setNewService({ ...newService, description: e.target.value })}
              placeholder="Description (English)" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <input value={newService.fee} onChange={(e) => setNewService({ ...newService, fee: e.target.value })}
              placeholder="ክፍያ / Fee" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <input value={newService.processing_time} onChange={(e) => setNewService({ ...newService, processing_time: e.target.value })}
              placeholder="ጊዜ / Processing time" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
          </div>
          <div className="flex gap-2">
            <button type="submit" disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-lg eth-gradient px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} ጨምር / Save
            </button>
            <button type="button" onClick={() => setAdding(false)}
              className="rounded-lg border border-border px-4 py-2 text-sm text-muted-foreground hover:text-foreground">
              ሰርዝ / Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

function AnnouncementManager({ officeId }: { officeId: string }) {
  const queryClient = useQueryClient();
  const [newAnn, setNewAnn] = useState({ title: '', title_am: '', content: '', content_am: '', type: 'info' });
  const [adding, setAdding] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnn.title || !newAnn.title_am) return;
    setSaving(true);
    await supabase.from('announcements').insert({
      office_id: officeId,
      title: newAnn.title,
      title_am: newAnn.title_am,
      content: newAnn.content,
      content_am: newAnn.content_am,
      type: newAnn.type,
    });
    setNewAnn({ title: '', title_am: '', content: '', content_am: '', type: 'info' });
    setAdding(false);
    setSaving(false);
    queryClient.invalidateQueries({ queryKey: ['offices'] });
    queryClient.invalidateQueries({ queryKey: ['office'] });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-lg font-semibold text-foreground flex items-center gap-2">
          <Megaphone className="h-5 w-5 text-secondary" />
          ማስታወቂያዎች / Announcements
        </h2>
        <button
          onClick={() => setAdding(!adding)}
          className="inline-flex items-center gap-1.5 rounded-lg gold-gradient px-3 py-2 text-sm font-medium text-accent-foreground"
        >
          <Plus className="h-4 w-4" /> አዲስ / Add
        </button>
      </div>

      {adding && (
        <form onSubmit={handleAdd} className="glass-card rounded-xl p-5 mb-4 space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <input value={newAnn.title_am} onChange={(e) => setNewAnn({ ...newAnn, title_am: e.target.value })}
              placeholder="ርዕስ (አማርኛ)" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <input value={newAnn.title} onChange={(e) => setNewAnn({ ...newAnn, title: e.target.value })}
              placeholder="Title (English)" className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <textarea value={newAnn.content_am} onChange={(e) => setNewAnn({ ...newAnn, content_am: e.target.value })}
              placeholder="ይዘት (አማርኛ)" rows={2} className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <textarea value={newAnn.content} onChange={(e) => setNewAnn({ ...newAnn, content: e.target.value })}
              placeholder="Content (English)" rows={2} className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
          </div>
          <select value={newAnn.type} onChange={(e) => setNewAnn({ ...newAnn, type: e.target.value })}
            className="rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring">
            <option value="info">ℹ️ መረጃ / Info</option>
            <option value="warning">⚠️ ማስጠንቀቂያ / Warning</option>
            <option value="urgent">🚨 አስቸኳይ / Urgent</option>
          </select>
          <div className="flex gap-2">
            <button type="submit" disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-lg gold-gradient px-4 py-2 text-sm font-medium text-accent-foreground disabled:opacity-50">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} ጨምር / Post
            </button>
            <button type="button" onClick={() => setAdding(false)}
              className="rounded-lg border border-border px-4 py-2 text-sm text-muted-foreground hover:text-foreground">
              ሰርዝ / Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export default AdminDashboard;
