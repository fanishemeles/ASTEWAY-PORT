import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Send, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const searchDatabase = async (query: string): Promise<string> => {
  const q = `%${query}%`;
  const { data: services } = await supabase
    .from('services')
    .select(`*, offices!inner(name, name_am), service_documents(name, name_am, sort_order)`)
    .or(`name.ilike.${q},name_am.ilike.${q}`);

  if (services && services.length > 0) {
    return services.map((s: any) => {
      const docs = (s.service_documents || [])
        .sort((a: any, b: any) => a.sort_order - b.sort_order)
        .map((d: any) => `• ${d.name_am} (${d.name})`).join('\n');
      return `📋 **${s.name_am}** (${s.name})\n🏢 ${s.offices?.name_am}\n\nየሚያስፈልጉ ሰነዶች:\n${docs}\n\n` +
        (s.fee ? `💰 ${s.fee}\n` : '') +
        (s.processing_time ? `⏱ ${s.processing_time}\n` : '') +
        `📅 Updated: ${new Date(s.updated_at).toLocaleDateString()}`;
    }).join('\n\n---\n\n');
  }

  return 'ይቅርታ፣ ይህ መረጃ ገና አልተዘመነም። / Sorry, this information is not yet available.';
};

const ChatPage = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'ሰላም! ስለ መንግስት አገልግሎቶች ጥያቄ ካለዎት ይጠይቁ።\n\nHello! Ask about any government service.' },
  ]);
  const [input, setInput] = useState('');
  const [searching, setSearching] = useState(false);

  const handleSend = async () => {
    if (!input.trim() || searching) return;
    setMessages((prev) => [...prev, { role: 'user', content: input.trim() }]);
    setInput('');
    setSearching(true);
    const response = await searchDatabase(input.trim());
    setMessages((prev) => [...prev, { role: 'assistant', content: response }]);
    setSearching(false);
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container max-w-2xl py-8">
        <div className="text-center mb-6">
          <h1 className="font-display text-2xl font-bold text-foreground">💬 ጥያቄ ይጠይቁ / Ask a Question</h1>
          <p className="text-sm text-muted-foreground mt-1">ስለ ማንኛውም የመንግስት አገልግሎት ይጠይቁ</p>
        </div>
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="h-[500px] overflow-y-auto p-4 space-y-3">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-xl px-4 py-3 text-sm whitespace-pre-line ${
                  msg.role === 'user' ? 'eth-gradient text-primary-foreground' : 'bg-muted text-foreground'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {searching && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-xl px-4 py-3 text-sm text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" /> እየፈለግሁ ነው...
                </div>
              </div>
            )}
          </div>
          <div className="border-t border-border p-4">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex items-center gap-2">
              <input value={input} onChange={(e) => setInput(e.target.value)}
                placeholder="ፓስፖርት፣ የንግድ ፈቃድ... / passport, business license..."
                className="flex-1 rounded-lg border border-input bg-background px-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
              <button type="submit" disabled={searching}
                className="flex h-10 w-10 items-center justify-center rounded-lg eth-gradient text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50">
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ChatPage;
