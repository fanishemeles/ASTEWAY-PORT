import { useState } from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import OfficeTabs from '@/components/OfficeTabs';
import ChatWidget from '@/components/ChatWidget';
import Footer from '@/components/Footer';

const Index = () => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection onSearch={setSearchQuery} />
        <OfficeTabs searchQuery={searchQuery} />
      </main>
      <Footer />
      <ChatWidget />
    </div>
  );
};

export default Index;
