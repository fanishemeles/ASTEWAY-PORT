const Footer = () => (
  <footer className="border-t border-border bg-muted/50 py-8">
    <div className="container text-center">
      <div className="flex items-center justify-center gap-2 mb-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-md eth-gradient">
          <span className="text-sm font-bold text-primary-foreground">አ</span>
        </div>
        <span className="font-display font-bold text-foreground">ASTEWAY</span>
      </div>
      <p className="text-sm text-muted-foreground">
        ትክክለኛ መረጃ · ለሁሉም ዜጋ · Accurate information for every citizen
      </p>
      <p className="mt-2 text-xs text-muted-foreground/60">© 2026 ASTEWAY V1</p>
    </div>
  </footer>
);

export default Footer;
