import heroBg from '@/assets/hero-bg.jpg';
import { Search } from 'lucide-react';
import { useState } from 'react';

interface HeroSectionProps {
  onSearch?: (query: string) => void;
}

const HeroSection = ({ onSearch }: HeroSectionProps) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(query);
  };

  return (
    <section className="relative overflow-hidden">
      <img
        src={heroBg}
        alt="Government building in Addis Ababa"
        className="absolute inset-0 h-full w-full object-cover"
        width={1920}
        height={1024}
      />
      <div className="hero-overlay absolute inset-0" />
      <div className="relative container py-20 md:py-28">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary-foreground/20 bg-primary-foreground/10 px-4 py-1.5 text-sm text-primary-foreground/90">
            <span className="h-1.5 w-1.5 rounded-full bg-secondary animate-pulse" />
            የመንግስት አገልግሎት መረጃ ማዕከል
          </div>
          <h1 className="font-display text-4xl font-extrabold tracking-tight text-primary-foreground md:text-5xl lg:text-6xl text-balance">
            አስተዋይ
          </h1>
          <p className="mt-2 font-display text-xl font-semibold text-primary-foreground/90 md:text-2xl">
            ASTEWAY
          </p>
          <p className="mt-4 text-base text-primary-foreground/75 md:text-lg max-w-lg mx-auto">
            የሚያስፈልጎትን ሰነድ ይወቁ · ትክክለኛ መረጃ ያግኙ
            <br />
            <span className="text-sm opacity-75">Find what you need · Get accurate information</span>
          </p>
          <form onSubmit={handleSubmit} className="mt-8 flex items-center gap-2 mx-auto max-w-md">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ፓስፖርት፣ የንግድ ፈቃድ... / Passport, business license..."
                className="w-full rounded-lg border-0 bg-background py-3 pl-10 pr-4 text-sm text-foreground shadow-lg placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-secondary"
              />
            </div>
            <button
              type="submit"
              className="rounded-lg gold-gradient px-5 py-3 text-sm font-semibold text-accent-foreground shadow-lg transition-opacity hover:opacity-90"
            >
              ፈልግ
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
