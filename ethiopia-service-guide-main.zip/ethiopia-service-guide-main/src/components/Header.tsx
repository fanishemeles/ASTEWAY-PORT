import { Link } from 'react-router-dom';
import { MessageCircle, Shield } from 'lucide-react';

const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg eth-gradient">
            <span className="text-lg font-bold text-primary-foreground">አ</span>
          </div>
          <div className="flex flex-col">
            <span className="font-display text-lg font-bold leading-tight text-foreground tracking-tight">ASTEWAY</span>
            <span className="text-[10px] text-muted-foreground leading-none">አስተዋይ</span>
          </div>
        </Link>
        <nav className="flex items-center gap-2 sm:gap-4">
          <Link to="/" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            መነሻ
          </Link>
          <Link
            to="/chat"
            className="inline-flex items-center gap-1.5 rounded-lg eth-gradient px-3 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            <MessageCircle className="h-4 w-4" />
            <span className="hidden sm:inline">ጠይቅ</span>
          </Link>
          <Link
            to="/officer-login"
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">ኦፊሰር</span>
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
