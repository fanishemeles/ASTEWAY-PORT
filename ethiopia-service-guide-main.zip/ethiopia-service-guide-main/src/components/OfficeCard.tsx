import { Link } from 'react-router-dom';
import { DbOffice } from '@/hooks/useOffices';
import { Building, Briefcase, FileText, Car, Landmark, MapPin, Clock } from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  passport: Building,
  landmark: Landmark,
  'file-text': FileText,
  briefcase: Briefcase,
  building: Building,
  car: Car,
};

interface OfficeCardProps {
  office: DbOffice;
}

const OfficeCard = ({ office }: OfficeCardProps) => {
  const Icon = iconMap[office.icon] || Building;

  return (
    <Link
      to={`/office/${office.slug}`}
      className="group glass-card rounded-xl p-5 transition-all hover:shadow-lg hover:border-primary/30 hover:-translate-y-0.5"
    >
      <div className="flex items-start gap-4">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg eth-gradient text-primary-foreground">
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-display font-semibold text-foreground group-hover:text-primary transition-colors">
            {office.name_am}
          </h3>
          <p className="text-sm text-muted-foreground mt-0.5">{office.name}</p>
          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{office.description_am}</p>
          <div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground">
            {office.address && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="h-3 w-3" /> {office.address}
              </span>
            )}
            {office.working_hours && (
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3 w-3" /> {office.working_hours}
              </span>
            )}
          </div>
          <div className="mt-3 flex items-center gap-1.5">
            <span className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              {office.services.length} አገልግሎቶች / services
            </span>
            {office.announcements.length > 0 && (
              <span className="rounded-md bg-secondary/20 px-2 py-0.5 text-xs font-medium text-secondary-foreground">
                {office.announcements.length} ማስታወቂያ
              </span>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default OfficeCard;
