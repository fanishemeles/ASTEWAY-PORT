import { useState, useMemo } from 'react';
import { useOffices } from '@/hooks/useOffices';
import OfficeCard from './OfficeCard';
import { Building2, Landmark, Loader2 } from 'lucide-react';

interface OfficeTabsProps {
  searchQuery?: string;
}

const OfficeTabs = ({ searchQuery = '' }: OfficeTabsProps) => {
  const [activeTab, setActiveTab] = useState<'federal' | 'addis-ababa'>('federal');
  const { data: offices, isLoading } = useOffices();

  const filteredOffices = useMemo(() => {
    if (!offices) return [];
    const q = searchQuery.toLowerCase();
    return offices
      .filter((o) => o.category === activeTab)
      .filter(
        (o) =>
          !q ||
          o.name.toLowerCase().includes(q) ||
          o.name_am.includes(q) ||
          o.services.some(
            (s) => s.name.toLowerCase().includes(q) || s.name_am.includes(q)
          )
      );
  }, [activeTab, searchQuery, offices]);

  const tabs = [
    { id: 'federal' as const, label: 'ፌዴራል መስሪያ ቤቶች', labelEn: 'Federal Offices', icon: Landmark },
    { id: 'addis-ababa' as const, label: 'የአዲስ አበባ መስሪያ ቤቶች', labelEn: 'Addis Ababa Offices', icon: Building2 },
  ];

  return (
    <section className="container py-10">
      <div className="flex items-center justify-center gap-2 mb-8">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold transition-all ${
              activeTab === tab.id
                ? 'eth-gradient text-primary-foreground shadow-md'
                : 'bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80'
            }`}
          >
            <tab.icon className="h-4 w-4" />
            <span className="hidden sm:inline">{tab.label}</span>
            <span className="sm:hidden">{tab.labelEn}</span>
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filteredOffices.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <p className="text-lg">ውጤት አልተገኘም</p>
          <p className="text-sm mt-1">No results found. Try a different search.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredOffices.map((office, i) => (
            <div key={office.id} className="animate-fade-up" style={{ animationDelay: `${i * 80}ms` }}>
              <OfficeCard office={office} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
};

export default OfficeTabs;
