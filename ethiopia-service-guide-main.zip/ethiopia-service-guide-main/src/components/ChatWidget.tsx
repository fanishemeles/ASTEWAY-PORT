import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const searchDatabase = async (query: string): Promise<string> => {
  const q = `%${query}%`;

  // Search services
  const { data: services } = await supabase
    .from('services')
    .select(`
      *,
      offices!inner (name, name_am),
      service_documents (name, name_am, sort_order)
    `)
    .or(`name.ilike.${q},name_am.ilike.${q}`);

  // Also search in documents
  const { data: docMatches } = await supabase
    .from('service_documents')
    .select(`
      name, name_am,
      services!inner (
        id, name, name_am, fee, processing_time, updated_at,
        offices!inner (name, name_am),
        service_documents (name, name_am, sort_order)
      )
    `)
    .or(`name.ilike.${q},name_am.ilike.${q}`);

  const allServices = new Map<string, any>();

  services?.forEach((s) => {
    allServices.set(s.id, s);
  });

  docMatches?.forEach((d: any) => {
    const s = d.services;
    if (s && !allServices.has(s.id)) {
      allServices.set(s.id, s);
    }
  });

  if (allServices.size > 0) {
    const results: string[] = [];
    allServices.forEach((s: any) => {
      const office = s.offices || {};
      const docs = (s.service_documents || [])
        .sort((a: any, b: any) => a.sort_order - b.sort_order)
        .map((d: any) => `• ${d.name_am} (${d.name})`)
        .join('\n');
      results.push(
        `📋 **${s.name_am}** (${s.name})\n🏢 ${office.name_am || ''}\n\n` +
        `የሚያስፈልጉ ሰነዶች / Required Documents:\n${docs}\n\n` +
        (s.fee ? `💰 ክፍያ / Fee: ${s.fee}\n` : '') +
        (s.processing_time ? `⏱ ጊዜ / Processing: ${s.processing_time}\n` : '') +
        `\n📅 Last updated: ${new Date(s.updated_at).toLocaleDateString()}`
      );
    });
    return results.join('\n\n---\n\n');
  }

  return (
    'ይቅርታ፣ ይህ መረጃ ገና አልተዘመነም።\n\n' +
    'Sorry, this information is not yet available in our database. ' +
    'Please visit the relevant office directly or check back later.'
  );
};

const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content:
        'ሰላም! ስለ መንግስት አገልግሎቶች ጥያቄ ካለዎት ይጠይቁ።\n\nHello! Ask me about any government service — e.g. "passport", "business license".',
    },
  ]);
  const [input, setInput] = useState('');
  const [searching, setSearching] = useState(false);

  const handleSend = async () => {
    if (!input.trim() || searching) return;
    const userMsg: Message = { role: 'user', content: input.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSearching(true);

    const response = await searchDatabase(input.trim());
    setMessages((prev) => [...prev, { role: 'assistant', content: response }]);
    setSearching(false);
  };

  return (
    <>
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full eth-gradient shadow-xl transition-transform hover:scale-105"
          aria-label="Open chat"
        >
          <MessageCircle className="h-6 w-6 text-primary-foreground" />
        </button>
      )}

      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 flex h-[480px] w-[360px] max-w-[calc(100vw-2rem)] flex-col rounded-2xl border border-border bg-card shadow-2xl">
          <div className="flex items-center justify-between rounded-t-2xl eth-gradient px-4 py-3">
            <div>
              <p className="font-display font-semibold text-primary-foreground text-sm">አስተዋይ ረዳት</p>
              <p className="text-xs text-primary-foreground/70">ASTEWAY Assistant</p>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-primary-foreground/70 hover:text-primary-foreground">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-sm whitespace-pre-line ${
                    msg.role === 'user'
                      ? 'eth-gradient text-primary-foreground'
                      : 'bg-muted text-foreground'
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
            {searching && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-xl px-3.5 py-2.5 text-sm text-muted-foreground animate-pulse">
                  እየፈለግሁ ነው... / Searching...
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-border p-3">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex items-center gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="ፓስፖርት፣ የንግድ ፈቃድ... / passport..."
                className="flex-1 rounded-lg border border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
              />
              <button
                type="submit"
                disabled={searching}
                className="flex h-9 w-9 items-center justify-center rounded-lg eth-gradient text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatWidget;
