
-- Create timestamp update function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- OFFICES TABLE
CREATE TABLE public.offices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  name_am TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('federal', 'addis-ababa')),
  description TEXT NOT NULL DEFAULT '',
  description_am TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT 'building',
  address TEXT,
  phone TEXT,
  working_hours TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.offices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view offices" ON public.offices FOR SELECT USING (true);
CREATE TRIGGER update_offices_updated_at BEFORE UPDATE ON public.offices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- SERVICES TABLE
CREATE TABLE public.services (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  office_id UUID NOT NULL REFERENCES public.offices(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  name_am TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  description_am TEXT NOT NULL DEFAULT '',
  fee TEXT,
  processing_time TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view services" ON public.services FOR SELECT USING (true);
CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- SERVICE_DOCUMENTS TABLE
CREATE TABLE public.service_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  service_id UUID NOT NULL REFERENCES public.services(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  name_am TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.service_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view service_documents" ON public.service_documents FOR SELECT USING (true);

-- ANNOUNCEMENTS TABLE
CREATE TABLE public.announcements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  office_id UUID NOT NULL REFERENCES public.offices(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  title_am TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  content_am TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL DEFAULT 'info' CHECK (type IN ('info', 'warning', 'urgent')),
  published_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view announcements" ON public.announcements FOR SELECT USING (true);
CREATE TRIGGER update_announcements_updated_at BEFORE UPDATE ON public.announcements FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- OFFICER PROFILES TABLE
CREATE TABLE public.officer_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  phone TEXT,
  office_id UUID REFERENCES public.offices(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.officer_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Officers can view own profile" ON public.officer_profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Officers can update own profile" ON public.officer_profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE TRIGGER update_officer_profiles_updated_at BEFORE UPDATE ON public.officer_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helper function to check officer access
CREATE OR REPLACE FUNCTION public.is_officer_of_office(_user_id uuid, _office_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.officer_profiles
    WHERE user_id = _user_id AND office_id = _office_id
  )
$$;

-- Officer write policies
CREATE POLICY "Officers can update own office" ON public.offices FOR UPDATE USING (public.is_officer_of_office(auth.uid(), id));
CREATE POLICY "Officers can insert services" ON public.services FOR INSERT WITH CHECK (public.is_officer_of_office(auth.uid(), office_id));
CREATE POLICY "Officers can update services" ON public.services FOR UPDATE USING (public.is_officer_of_office(auth.uid(), office_id));
CREATE POLICY "Officers can delete services" ON public.services FOR DELETE USING (public.is_officer_of_office(auth.uid(), office_id));
CREATE POLICY "Officers can insert documents" ON public.service_documents FOR INSERT WITH CHECK (EXISTS (SELECT 1 FROM public.services s WHERE s.id = service_id AND public.is_officer_of_office(auth.uid(), s.office_id)));
CREATE POLICY "Officers can update documents" ON public.service_documents FOR UPDATE USING (EXISTS (SELECT 1 FROM public.services s WHERE s.id = service_id AND public.is_officer_of_office(auth.uid(), s.office_id)));
CREATE POLICY "Officers can delete documents" ON public.service_documents FOR DELETE USING (EXISTS (SELECT 1 FROM public.services s WHERE s.id = service_id AND public.is_officer_of_office(auth.uid(), s.office_id)));
CREATE POLICY "Officers can insert announcements" ON public.announcements FOR INSERT WITH CHECK (public.is_officer_of_office(auth.uid(), office_id));
CREATE POLICY "Officers can update announcements" ON public.announcements FOR UPDATE USING (public.is_officer_of_office(auth.uid(), office_id));
CREATE POLICY "Officers can delete announcements" ON public.announcements FOR DELETE USING (public.is_officer_of_office(auth.uid(), office_id));

-- Auto-create officer profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_officer()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.officer_profiles (user_id, full_name, phone)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), NEW.phone);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_officer();
